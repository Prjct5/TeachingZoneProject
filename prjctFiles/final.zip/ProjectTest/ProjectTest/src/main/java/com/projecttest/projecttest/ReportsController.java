package com.projecttest.projecttest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReportsController {

    @FXML
    private TableView<ReportItem> reportsTable;
    @FXML
    private TableColumn<ReportItem, String> categoryColumn;
    @FXML
    private TableColumn<ReportItem, Integer> countColumn;
    @FXML
    private Button refreshButton;
    @FXML
    private Button backButton;
    @FXML
    private Label statusLabel;

    private ObservableList<ReportItem> reportsList = FXCollections.observableArrayList();

    public static class ReportItem {
        private final String category;
        private final int count;

        public ReportItem(String category, int count) {
            this.category = category;
            this.count = count;
        }

        public String getCategory() { return category; }
        public int getCount() { return count; }
    }

    @FXML
    private void initialize() {
        categoryColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleStringProperty(cellData.getValue().getCategory()));
        countColumn.setCellValueFactory(cellData -> new javafx.beans.property.SimpleIntegerProperty(cellData.getValue().getCount()).asObject());
        loadReports();
    }

    private void loadReports() {
        reportsList.clear();
        try {
            Connection conn = Database.getConnection();
            // Count users by role
            String[] roles = {"Admin", "Student", "Teacher"};
            for (String role : roles) {
                String sql = "SELECT COUNT(*) FROM users WHERE role = ?";
                PreparedStatement pstmt = conn.prepareStatement(sql);
                pstmt.setString(1, role);
                ResultSet rs = pstmt.executeQuery();
                if (rs.next()) {
                    reportsList.add(new ReportItem("Users: " + role, rs.getInt(1)));
                }
            }
            // Count courses
            ResultSet rsCourses = conn.createStatement().executeQuery("SELECT COUNT(*) FROM courses");
            if (rsCourses.next()) {
                reportsList.add(new ReportItem("Total Courses", rsCourses.getInt(1)));
            }
            // Count assignments (using getAssignments for a specific course as example, or aggregate)
            ResultSet rsAssignments = conn.createStatement().executeQuery("SELECT COUNT(*) FROM assignments");
            if (rsAssignments.next()) {
                reportsList.add(new ReportItem("Total Assignments", rsAssignments.getInt(1)));
            }
            conn.close();
            reportsTable.setItems(reportsList);
            statusLabel.setText("Reports loaded successfully");
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error loading reports: " + e.getMessage());
        }
    }

    @FXML
    private void handleRefresh() {
        loadReports();
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Admin Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
            Stage currentStage = (Stage) backButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error opening dashboard");
        }
    }
}