package com.projecttest.projecttest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.control.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DataManagementController {

    @FXML
    private TextField searchField;
    @FXML
    private ListView<String> userListView;
    @FXML
    private TextField usernameField;
    @FXML
    private TextField emailField;
    @FXML
    private PasswordField passwordField;
    @FXML
    private ComboBox<String> roleComboBox;
    @FXML
    private Button updateButton;
    @FXML
    private Button backButton;
    @FXML
    private Label statusLabel;

    private ObservableList<String> usernames = FXCollections.observableArrayList();

    @FXML
    private void initialize() {
        // Populate roleComboBox (defined in FXML)
        roleComboBox.getSelectionModel().selectFirst();
        // Initialize userListView
        userListView.setItems(usernames);
        // Trigger initial search to show all users
        handleSearch();
    }

    @FXML
    private void handleSearch() {
        usernames.clear();
        String searchText = searchField.getText().trim().toLowerCase();
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT username FROM users WHERE LOWER(username) LIKE ? ORDER BY username";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + searchText + "%");
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                usernames.add(rs.getString("username"));
            }
            if (usernames.isEmpty()) {
                statusLabel.setText("No users found");
            } else {
                statusLabel.setText("");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error searching users: " + e.getMessage());
        }
    }

    @FXML
    private void handleUserSelection() {
        String selectedUser = userListView.getSelectionModel().getSelectedItem();
        if (selectedUser != null) {
            try (Connection conn = Database.getConnection()) {
                String sql = "SELECT username, email, password, role FROM users WHERE username = ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, selectedUser);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    usernameField.setText(rs.getString("username"));
                    emailField.setText(rs.getString("email"));
                    passwordField.setText(rs.getString("password"));
                    roleComboBox.getSelectionModel().select(rs.getString("role"));
                    statusLabel.setText("");
                }
            } catch (SQLException e) {
                e.printStackTrace();
                statusLabel.setText("Error loading user data: " + e.getMessage());
            }
        }
    }

    @FXML
    private void handleUpdateUser() {
        String selectedUser = userListView.getSelectionModel().getSelectedItem();
        if (selectedUser == null) {
            statusLabel.setText("Please select a user");
            return;
        }

        String newUsername = usernameField.getText().trim();
        String email = emailField.getText().trim();
        String password = passwordField.getText().trim();
        String role = roleComboBox.getSelectionModel().getSelectedItem();

        // Validate inputs
        if (newUsername.isEmpty() || email.isEmpty() || password.isEmpty() || role == null) {
            statusLabel.setText("Please fill all fields");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            // Check for username conflict
            String checkSql = "SELECT 1 FROM users WHERE username = ? AND username != ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, newUsername);
            checkStmt.setString(2, selectedUser);
            ResultSet checkRs = checkStmt.executeQuery();
            if (checkRs.next()) {
                statusLabel.setText("Username already exists");
                return;
            }

            // Update user
            String sql = "UPDATE users SET username = ?, email = ?, password = ?, role = ? WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, newUsername);
            stmt.setString(2, email);
            stmt.setString(3, password);
            stmt.setString(4, role);
            stmt.setString(5, selectedUser);
            int rowsAffected = stmt.executeUpdate();

            if (rowsAffected > 0) {
                statusLabel.setText("User updated successfully");
                // Update usernames list if username changed
                if (!newUsername.equals(selectedUser)) {
                    usernames.remove(selectedUser);
                    usernames.add(newUsername);
                    FXCollections.sort(usernames);
                    userListView.getSelectionModel().select(newUsername);
                }
            } else {
                statusLabel.setText("Error: User not found or no changes made");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            statusLabel.setText("Error updating user: " + e.getMessage());
        }
    }

    @FXML
    private void handleBack() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdminDashboard.fxml"));
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setTitle("Admin Dashboard");
            stage.setScene(new Scene(root));
            stage.show();
            Stage currentStage = (Stage) backButton.getScene().getWindow();
            currentStage.close();
        } catch (IOException e) {
            e.printStackTrace();
            statusLabel.setText("Error opening Admin Dashboard");
        }
    }
}