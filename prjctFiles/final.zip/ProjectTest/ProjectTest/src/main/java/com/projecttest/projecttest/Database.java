package com.projecttest.projecttest;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class Database {
    private static final String URL = "jdbc:postgresql://localhost:5432/oop2";
    private static final String USER = "postgres";
    private static final String PASSWORD = "ym";

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("org.postgresql.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("PostgreSQL JDBC Driver not found");
        }
    }

    // Register user
    public static boolean registerUser(String username, String email, String password, String role) {
        String checkSql = "SELECT username FROM users WHERE username = ?";
        String insertSql = "INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            // Check if username exists
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, username);
            ResultSet rs = checkStmt.executeQuery();
            if (rs.next()) {
                return false; // Username already exists
            }

            // Insert new user
            PreparedStatement insertStmt = conn.prepareStatement(insertSql);
            insertStmt.setString(1, username);
            insertStmt.setString(2, email);
            insertStmt.setString(3, password); // Store password as plain text
            insertStmt.setString(4, role);
            insertStmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Login user
    public static Map<String, String> loginUser(String username, String password) {
        String sql = "SELECT id, email, password, role FROM users WHERE username = ?";

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String storedPassword = rs.getString("password");
                if (password.equals(storedPassword)) { // Compare plain text password
                    Map<String, String> userData = new HashMap<>();
                    userData.put("id", rs.getString("id"));
                    userData.put("email", rs.getString("email"));
                    userData.put("role", rs.getString("role"));
                    Info.currentUser = username; // Set current user for compatibility
                    Info.currentRole = rs.getString("role");
                    return userData;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    // Add student data
    public static boolean addStudent(int userId, String studentId, String organisation, String level, double gpa, String fullName) {
        String sql = "INSERT INTO students (user_id, student_id, organisation, level, gpa, full_name) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setString(2, studentId);
            stmt.setString(3, organisation);
            stmt.setString(4, level);
            stmt.setDouble(5, gpa);
            stmt.setString(6, fullName);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add course
    public static boolean addCourse(String title, String description, int instructorId, String requirements) {
        String validateSql = "SELECT id FROM users WHERE id = ? AND role = 'Teacher'";
        String courseSql = "INSERT INTO courses (title, description, instructor_id, requirements) VALUES (?, ?, ?, ?) RETURNING id";
        String teacherSql = "INSERT INTO course_teachers (course_id, teacher_id) VALUES (?, ?)";

        try (Connection conn = getConnection()) {
            conn.setAutoCommit(false); // Start transaction
            try {
                // Validate instructorId
                PreparedStatement validateStmt = conn.prepareStatement(validateSql);
                validateStmt.setInt(1, instructorId);
                ResultSet rsValidate = validateStmt.executeQuery();
                if (!rsValidate.next()) {
                    System.err.println("Invalid instructor ID: " + instructorId + " or not a Teacher");
                    return false;
                }

                // Insert course
                PreparedStatement courseStmt = conn.prepareStatement(courseSql);
                courseStmt.setString(1, title);
                courseStmt.setString(2, description);
                courseStmt.setInt(3, instructorId);
                courseStmt.setString(4, requirements);
                ResultSet rs = courseStmt.executeQuery();
                if (rs.next()) {
                    int courseId = rs.getInt("id");
                    // Insert into course_teachers
                    PreparedStatement teacherStmt = conn.prepareStatement(teacherSql);
                    teacherStmt.setInt(1, courseId);
                    teacherStmt.setInt(2, instructorId);
                    teacherStmt.executeUpdate();
                }
                conn.commit();
                return true;
            } catch (SQLException e) {
                conn.rollback();
                e.printStackTrace();
                return false;
            } finally {
                conn.setAutoCommit(true);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add course video
    public static boolean addCourseVideo(int courseId, String title, String description, String videoUrl, String videoFilePath, int duration, int orderNumber) {
        String sql = "INSERT INTO course_videos (course_id, title, description, video_url, video_file_path, duration, order_number) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            stmt.setString(2, title);
            stmt.setString(3, description);
            stmt.setString(4, videoUrl);
            stmt.setString(5, videoFilePath);
            stmt.setInt(6, duration);
            stmt.setInt(7, orderNumber);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Enroll student in course
    public static boolean enrollStudentInCourse(int userId, int courseId) {
        // Check if student record exists
        String checkSql = "SELECT id FROM students WHERE user_id = ?";
        try (Connection conn = getConnection(); PreparedStatement checkStmt = conn.prepareStatement(checkSql)) {
            checkStmt.setInt(1, userId);
            ResultSet rs = checkStmt.executeQuery();
            if (!rs.next()) {
                // Create student record if it doesn't exist
                createStudentRecord(userId);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }

        // Enroll student
        String sql = "INSERT INTO course_enrollments (student_id, course_id) VALUES ((SELECT id FROM students WHERE user_id = ?), ?) ON CONFLICT DO NOTHING";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, userId);
            stmt.setInt(2, courseId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Create student record
    private static void createStudentRecord(int userId) throws SQLException {
        String sql = "INSERT INTO students (user_id, student_id, organisation, level, gpa, full_name) VALUES (?, ?, ?, ?, ?, ?) ON CONFLICT (user_id) DO NOTHING";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            // Fetch user details to populate student record
            String userSql = "SELECT username, email FROM users WHERE id = ?";
            try (PreparedStatement userStmt = conn.prepareStatement(userSql)) {
                userStmt.setInt(1, userId);
                ResultSet rs = userStmt.executeQuery();
                if (rs.next()) {
                    String username = rs.getString("username");
                    stmt.setInt(1, userId);
                    stmt.setString(2, "STU" + userId); // Generate student_id
                    stmt.setString(3, "Unknown"); // Default organisation
                    stmt.setString(4, "Unknown"); // Default level
                    stmt.setDouble(5, 0.0); // Default GPA
                    stmt.setString(6, username); // Use username as full_name
                    stmt.executeUpdate();
                }
            }
        }
    }

    // Enroll student in course (old version)
    public static boolean enrollStudentInCourseOld(int studentId, int courseId) {
        String sql = "INSERT INTO course_enrollments (student_id, course_id) VALUES (?, ?)";

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, studentId);
            stmt.setInt(2, courseId);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Add assignment
    public static boolean addAssignment(int courseId, String title, String description, Timestamp dueDate, int maxGrade) {
        String sql = "INSERT INTO assignments (course_id, title, description, due_date, max_grade) VALUES (?, ?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            stmt.setString(2, title);
            stmt.setString(3, description);
            stmt.setTimestamp(4, dueDate);
            stmt.setInt(5, maxGrade);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Submit assignment
    public static boolean submitAssignment(int assignmentId, int userId, Timestamp submissionDate, String submissionText) {
        String sql = "INSERT INTO assignment_submissions (assignment_id, student_id, submission_date, submission_text) VALUES (?, (SELECT id FROM students WHERE user_id = ?), ?, ?) ON CONFLICT DO NOTHING";
        try (Connection conn = getConnection(); PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, assignmentId);
            stmt.setInt(2, userId);
            stmt.setTimestamp(3, submissionDate != null ? submissionDate : new Timestamp(System.currentTimeMillis()));
            stmt.setString(4, submissionText);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Submit assignment (old version)
    public static boolean submitAssignmentOld(int assignmentId, int studentId, String submissionFile, String submissionText) {
        String sql = "INSERT INTO assignment_submissions (assignment_id, student_id, submission_file, submission_text) VALUES (?, ?, ?, ?)";

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, assignmentId);
            stmt.setInt(2, studentId);
            stmt.setString(3, submissionFile);
            stmt.setString(4, submissionText);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Save system setting
    public static boolean saveSetting(String name, String value) {
        String sql = "INSERT INTO settings (setting_name, setting_value) VALUES (?, ?) ON CONFLICT (setting_name) DO UPDATE SET setting_value = ?, updated_at = CURRENT_TIMESTAMP";

        try (Connection conn = getConnection()) {
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, name);
            stmt.setString(2, value);
            stmt.setString(3, value);
            stmt.executeUpdate();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get course videos
    public static ResultSet getCourseVideos(int courseId) {
        String sql = "SELECT id, title, description, video_url, video_file_path, duration, order_number FROM course_videos WHERE course_id = ? ORDER BY order_number";

        try {
            Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            return stmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }

    // Get assignments for a course
    public static ResultSet getAssignments(int courseId) {
        String sql = "SELECT id, title, description, due_date, max_grade FROM assignments WHERE course_id = ?";

        try {
            Connection conn = getConnection();
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, courseId);
            return stmt.executeQuery();
        } catch (SQLException e) {
            e.printStackTrace();
            return null;
        }
    }
}