package com.projecttest.projecttest;

// Interface to define user management operations (Abstraction)
public interface UserOperations {
    boolean addUser(String username, String email, String password, String role);
    boolean removeUser(int userId);
    String getUserDetails(int userId);
}