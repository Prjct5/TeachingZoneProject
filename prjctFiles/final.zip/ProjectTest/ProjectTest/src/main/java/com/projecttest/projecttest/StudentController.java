package com.projecttest.projecttest;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

public class StudentController {

    @FXML
    private VBox contentArea;
    @FXML
    private Button coursesButton;
    @FXML
    private Button videosButton;
    @FXML
    private Button tasksButton;
    @FXML
    private Button backButtonPrev;
    @FXML
    private Button backButtonLogin;
    @FXML
    private Label statusLabel;

    @FXML
    private void initialize() {
        statusLabel.setText("Welcome to Student Dashboard");
    }

    @FXML
    private void handleViewCourses() {
        contentArea.getChildren().clear();
        Label searchLabel = new Label("Search Teacher:");
        TextField teacherSearchField = new TextField();
        teacherSearchField.setPromptText("Enter teacher username");
        ListView<String> teacherListView = new ListView<>();
        teacherListView.setMaxHeight(100);
        ListView<String> courseListView = new ListView<>();
        courseListView.setMaxHeight(100);
        TextField courseIdField = new TextField();
        courseIdField.setPromptText("Enter Course ID to Enroll");
        Button enrollButton = new Button("Enroll");
        enrollButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");

        ObservableList<String> teachers = FXCollections.observableArrayList();
        ObservableList<String> courses = FXCollections.observableArrayList();
        teacherListView.setItems(teachers);
        courseListView.setItems(courses);

        // Search teachers
        teacherSearchField.setOnKeyReleased(e -> {
            teachers.clear();
            courses.clear();
            courseListView.getSelectionModel().clearSelection();
            String searchText = teacherSearchField.getText().trim().toLowerCase();
            try (Connection conn = Database.getConnection()) {
                String sql = "SELECT username FROM users WHERE LOWER(username) LIKE ? AND role = 'Teacher' ORDER BY username";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, "%" + searchText + "%");
                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    teachers.add(rs.getString("username"));
                }
                statusLabel.setText(teachers.isEmpty() ? "No teachers found" : "");
            } catch (SQLException ex) {
                statusLabel.setText("Error searching teachers: " + ex.getMessage());
            }
        });

        // Load courses for selected teacher
        teacherListView.getSelectionModel().selectedItemProperty().addListener((obs, old, newValue) -> {
            courses.clear();
            courseListView.getSelectionModel().clearSelection();
            if (newValue != null) {
                try (Connection conn = Database.getConnection()) {
                    String sql = "SELECT c.id, c.title, c.description " +
                            "FROM courses c " +
                            "JOIN users u ON c.instructor_id = u.id " +
                            "WHERE u.username = ? AND u.role = 'Teacher'";
                    PreparedStatement stmt = conn.prepareStatement(sql);
                    stmt.setString(1, newValue);
                    ResultSet rs = stmt.executeQuery();
                    while (rs.next()) {
                        courses.add("ID: " + rs.getInt("id") + " - " + rs.getString("title") + " - " + rs.getString("description"));
                    }
                    statusLabel.setText(courses.isEmpty() ? "No courses found for this teacher" : "");
                } catch (SQLException ex) {
                    statusLabel.setText("Error loading courses: " + ex.getMessage());
                }
            }
        });

        // Enroll in course
        enrollButton.setOnAction(e -> {
            String courseIdText = courseIdField.getText().trim();
            if (courseIdText.isEmpty()) {
                statusLabel.setText("Please enter a Course ID");
                return;
            }
            try {
                int courseId = Integer.parseInt(courseIdText);
                int userId = getCurrentUserId();
                if (userId == -1) {
                    statusLabel.setText("User not found");
                    return;
                }
                boolean success = Database.enrollStudentInCourse(userId, courseId);
                if (success) {
                    statusLabel.setText("Enrolled in course successfully");
                    courseIdField.clear();
                } else {
                    try (Connection conn = Database.getConnection()) {
                        String sql = "SELECT id FROM students WHERE user_id = ?";
                        PreparedStatement stmt = conn.prepareStatement(sql);
                        stmt.setInt(1, userId);
                        ResultSet rs = stmt.executeQuery();
                        if (!rs.next()) {
                            statusLabel.setText("Error: Student profile not set up. Contact admin.");
                        } else {
                            statusLabel.setText("Failed to enroll. Course may not exist or already enrolled.");
                        }
                    }
                }
            } catch (NumberFormatException ex) {
                statusLabel.setText("Invalid Course ID format");
            } catch (SQLException ex) {
                statusLabel.setText("Database error: " + ex.getMessage());
            }
        });

        contentArea.getChildren().addAll(
                searchLabel, teacherSearchField, new Label("Teachers:"), teacherListView,
                new Label("Courses:"), courseListView, courseIdField, enrollButton
        );
        statusLabel.setText("Search for a teacher to view their courses");
    }

    @FXML
    private void handleWatchVideos() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Videos Available:"));
        TextField courseIdField = new TextField();
        courseIdField.setPromptText("Enter Course ID to View Videos");
        Button loadVideosButton = new Button("Load Videos");
        loadVideosButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");

        loadVideosButton.setOnAction(e -> {
            String courseIdText = courseIdField.getText().trim();
            if (courseIdText.isEmpty()) {
                statusLabel.setText("Please enter a Course ID");
                return;
            }
            try {
                int courseId = Integer.parseInt(courseIdText);
                ResultSet rs = Database.getCourseVideos(courseId);
                if (rs == null) {
                    statusLabel.setText("Error loading videos");
                    return;
                }
                contentArea.getChildren().clear();
                contentArea.getChildren().add(new Label("Videos for Course ID " + courseId + ":"));
                while (rs.next()) {
                    contentArea.getChildren().add(new Label(rs.getString("title") + " - " + rs.getString("video_url")));
                }
                rs.getStatement().getConnection().close();
                statusLabel.setText("Videos loaded");
            } catch (NumberFormatException ex) {
                statusLabel.setText("Invalid Course ID format");
            } catch (SQLException ex) {
                statusLabel.setText("Error loading videos: " + ex.getMessage());
            }
        });

        contentArea.getChildren().addAll(courseIdField, loadVideosButton);
        statusLabel.setText("Enter Course ID to load videos");
    }

    @FXML
    private void handleCheckTasks() {
        contentArea.getChildren().clear();
        contentArea.getChildren().add(new Label("Tasks Available:"));
        TextField courseIdField = new TextField();
        courseIdField.setPromptText("Enter Course ID to View Assignments");
        TextField assignmentIdField = new TextField();
        assignmentIdField.setPromptText("Enter Assignment ID to Submit");
        TextField submissionTextField = new TextField();
        submissionTextField.setPromptText("Enter Submission Text");
        Button loadTasksButton = new Button("Load Assignments");
        Button submitButton = new Button("Submit Assignment");
        loadTasksButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");
        submitButton.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-font-size: 14px;");

        loadTasksButton.setOnAction(e -> {
            String courseIdText = courseIdField.getText().trim();
            if (courseIdText.isEmpty()) {
                statusLabel.setText("Please enter a Course ID");
                return;
            }
            try {
                int courseId = Integer.parseInt(courseIdText);
                ResultSet rs = Database.getAssignments(courseId);
                if (rs == null) {
                    statusLabel.setText("Error loading assignments");
                    return;
                }
                contentArea.getChildren().clear();
                contentArea.getChildren().add(new Label("Assignments for Course ID " + courseId + ":"));
                while (rs.next()) {
                    contentArea.getChildren().add(new Label("ID: " + rs.getInt("id") + " - " + rs.getString("title") + " - Due: " + rs.getString("due_date")));
                }
                rs.getStatement().getConnection().close();
                contentArea.getChildren().addAll(courseIdField, assignmentIdField, submissionTextField, loadTasksButton, submitButton);
                statusLabel.setText("Assignments loaded");
            } catch (NumberFormatException ex) {
                statusLabel.setText("Invalid Course ID format");
            } catch (SQLException ex) {
                statusLabel.setText("Error loading assignments: " + ex.getMessage());
            }
        });

        submitButton.setOnAction(e -> {
            String assignmentIdText = assignmentIdField.getText().trim();
            String submissionText = submissionTextField.getText().trim();
            if (assignmentIdText.isEmpty() || submissionText.isEmpty()) {
                statusLabel.setText("Please enter Assignment ID and Submission Text");
                return;
            }
            try {
                int assignmentId = Integer.parseInt(assignmentIdText);
                int userId = getCurrentUserId();
                if (userId == -1) {
                    statusLabel.setText("User not found");
                    return;
                }
                boolean success = Database.submitAssignment(assignmentId, userId, null, submissionText);
                if (success) {
                    statusLabel.setText("Assignment submitted successfully");
                    assignmentIdField.clear();
                    submissionTextField.clear();
                } else {
                    statusLabel.setText("Failed to submit assignment");
                }
            } catch (NumberFormatException ex) {
                statusLabel.setText("Invalid Assignment ID format");
            }
        });

        contentArea.getChildren().addAll(courseIdField, assignmentIdField, submissionTextField, loadTasksButton, submitButton);
        statusLabel.setText("Enter Course ID to load assignments");
    }

    @FXML
    private void handleBackLogin() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("login.fxml"));
            Stage stage = (Stage) backButtonLogin.getScene().getWindow();
            stage.setScene(new Scene(loader.load()));
            stage.setTitle("Login");
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
            statusLabel.setText("Error returning to login");
        }
    }

    private int getCurrentUserId() {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT id FROM users WHERE username = ?";
            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, Info.currentUser);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return rs.getInt("id");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }
}