package com.projecttest.projecttest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

public class UserManager extends AbstractUserManager implements UserOperations {

    // Constructor inheriting from AbstractUserManager
    public UserManager() {
        super();
    }

    // Implementation of addUser (Polymorphism via interface)
    @Override
    public boolean addUser(String username, String email, String password, String role) {
        // Input validation (Encapsulation)
        if (username == null || email == null || password == null || role == null ||
                username.trim().isEmpty() || email.trim().isEmpty() || password.trim().isEmpty()) {
            return false;
        }

        // Check if user already exists
        if (userExists(username)) {
            return false;
        }

        // Delegate to Database class (using Database as an object)
        return getDatabase().registerUser(username, email, password, role);
    }

    // Implementation of removeUser (Polymorphism via interface)
    @Override
    public boolean removeUser(int userId) {
        try (Connection conn = getDatabase().getConnection()) {
            String sql = "DELETE FROM users WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            int rowsAffected = stmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Implementation of getUserDetails (Polymorphism via interface and method overriding)
    @Override
    public String getUserDetails(int userId) {
        try (Connection conn = getDatabase().getConnection()) {
            String sql = "SELECT username, email, role FROM users WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Map<String, String> userData = new HashMap<>();
                userData.put("username", rs.getString("username"));
                userData.put("email", rs.getString("email"));
                userData.put("role", rs.getString("role"));
                return formatUserDetails(userData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "User not found";
    }

    // Overridden method to format user details (Polymorphism)
    @Override
    protected String formatUserDetails(Map<String, String> userData) {
        return String.format("Username: %s, Email: %s, Role: %s",
                userData.get("username"), userData.get("email"), userData.get("role"));
    }

    // Overloaded method for polymorphism
    public String getUserDetails(String username) {
        try (Connection conn = getDatabase().getConnection()) {
            String sql = "SELECT username, email, role FROM users WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                Map<String, String> userData = new HashMap<>();
                userData.put("username", rs.getString("username"));
                userData.put("email", rs.getString("email"));
                userData.put("role", rs.getString("role"));
                return formatUserDetails(userData);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "User not found";
    }
}