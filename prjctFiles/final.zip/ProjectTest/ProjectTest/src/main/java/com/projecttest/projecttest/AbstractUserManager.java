package com.projecttest.projecttest;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

abstract class AbstractUserManager {
    // Encapsulated Database object
    private final Database database;

    // Constructor to initialize Database object (Dependency Injection)
    protected AbstractUserManager() {
        this.database = new Database();
    }

    // Protected method to access Database object (Encapsulation)
    protected Database getDatabase() {
        return database;
    }

    // Abstract method to be implemented by subclasses (Abstraction)
    protected abstract String formatUserDetails(Map<String, String> userData);

    // Common method to check if user exists (Encapsulation)
    protected boolean userExists(String username) {
        try (Connection conn = Database.getConnection()) {
            String sql = "SELECT COUNT(*) FROM users WHERE username = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}
