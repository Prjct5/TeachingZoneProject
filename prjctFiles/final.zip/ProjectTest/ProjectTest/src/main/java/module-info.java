module com.projecttest.projecttest {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.projecttest.projecttest to javafx.fxml;
    exports com.projecttest.projecttest;
}